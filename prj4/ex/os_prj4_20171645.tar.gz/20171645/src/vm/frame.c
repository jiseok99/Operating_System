#include <stdio.h>
#include <stdlib.h>
#include "threads/palloc.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "vm/page.h"
#include "vm/swap.h"
#include "vm/frame.h"

void frame_init()
{
	list_init(&frame_table);
}

struct frame_entry* frame_add(void *vaddr, void *paddr, bool writable)
{
	struct frame_entry *frame;
	frame = (struct frame_entry*)malloc(sizeof(struct frame_entry));

	frame->paddr = pg_round_down(paddr);
	frame->vaddr = pg_round_down(vaddr);
	frame->thread = thread_current();

	list_push_back(&frame_table, &frame->elem);

	if(paddr != NULL)
		return frame;
	else
		paddr = palloc_get_page(PAL_USER);

	return frame;
}

bool frame_remove(struct frame_entry *frame)
{
	list_remove(&frame->elem);
}

bool evict_frame()
{
	/* not implemented */
	return true;
}

