#ifndef VM_PAGE_H
#define VM_PAGE_H

#include <hash.h>
#include <list.h>
#include "threads/thread.h"
#include "threads/vaddr.h"

struct page_entry {
    void* vaddr;
    void* paddr;
    int swap_idx;
    bool writable;
    struct hash_elem elem
};

void grow_stack(struct thread*, const void*);

bool page_less_func(const struct hash_elem *hash_1, const struct hash_elem *hash_2, void *aux);
unsigned page_hash_func(const struct hash_elem *hash, void *aux);
void init_page_table(struct hash *page_table);
bool page_insert(void *vaddr, void *paddr, struct page_entry *page);
void page_delete(struct hash_elem* element, void* aux);
void page_table_destroy(struct hash *page_table);

struct page_entry *get_page_entry(struct hash *page_table, void *vaddr);

#endif