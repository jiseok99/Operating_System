#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "userprog/pagedir.h"
#include "threads/interrupt.h"
#include "threads/palloc.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "vm/page.h"
#include "vm/frame.h"
#include "vm/swap.h"

void grow_stack (struct thread *current_thread, const void *fault_addr){
	void *kpage = palloc_get_page(PAL_USER);
	void *upage = pg_round_down(fault_addr);
	pagedir_get_page(current_thread->pagedir, upage);
	pagedir_set_page(current_thread->pagedir, upage,kpage, true);
}

bool page_less_func(const struct hash_elem *hash_1, const struct hash_elem *hash_2, void *aux)
{
	struct page_entry* page_entry_1 = hash_entry(hash_1, struct page_entry, elem);
	struct page_entry* page_entry_2 = hash_entry(hash_2, struct page_entry, elem);

	return page_entry_2->vaddr <= page_entry_1->vaddr ? false : true;
}

unsigned page_hash_func(const struct hash_elem *hash, void *aux)
{
	struct page_entry* page = hash_entry(hash, struct page_entry, elem);

	return hash_bytes(&page->vaddr, sizeof(page->vaddr));
}

void init_page_table(struct hash *page_table)
{
	hash_init(page_table, page_hash_func, page_less_func, NULL);
}

bool page_insert(void *vaddr, void *paddr, struct page_entry *page)
{
	struct hash *page_table = &(thread_current()->page_table);
	page->vaddr = pg_round_down(vaddr);
	page->paddr = pg_round_down(paddr);
	
	if(!hash_find(page_table, &page->elem))
		hash_insert(page_table, &page->elem);
	else
	{
		page = hash_entry(hash_find(page_table, &page->elem), struct page_entry, elem);
		page->swap_idx = -1;
	}
	return true;
}

void page_delete(struct hash_elem* element, void* aux)
{
	struct page_entry* page = hash_entry(element, struct page_entry, elem);
	free(page);
}

void page_table_destroy(struct hash *page_table)
{
	hash_destroy(page_table, page_delete);
}

struct page_entry* get_page_entry(struct hash *page_table, void *vaddr)
{
	struct page_entry page;
	page.vaddr = pg_round_down(vaddr);
	struct hash_elem *element = hash_find(page_table, &page.elem);
	return element ? hash_entry(element, struct page_entry, elem) : NULL;
}



