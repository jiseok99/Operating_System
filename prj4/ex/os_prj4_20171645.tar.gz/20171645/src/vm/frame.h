#ifndef VM_FRAME_H
#define VM_FRAME_H
#include <list.h>
#include "vm/page.h"

struct frame_entry
{
	void *paddr;
	void *vaddr;
	struct thread *thread;
	struct list_elem elem;
};

struct list frame_table;

void frame_init();
struct frame_entry* frame_add(void *vaddr, void *paddr, bool writable);
bool frame_remove(struct frame_entry* frame);

bool evict_frame();
#endif