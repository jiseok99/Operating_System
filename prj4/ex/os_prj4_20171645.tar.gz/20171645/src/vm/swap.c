#include <stdio.h>
#include <stdlib.h>
#include <bitmap.h>
#include "threads/palloc.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "vm/page.h"
#include "vm/frame.h"
#include "vm/swap.h"
#include "devices/block.h"

struct block *swap_disk;
bool *swapped;

void swap_init()
{
	swap_disk = block_get_role(BLOCK_SWAP);
	int block_count = block_size(swap_disk) / (PGSIZE / BLOCK_SECTOR_SIZE);
	int i;
	
	if(swap_disk)
	{
		swapped = malloc(sizeof(bool) * block_count);

		for(i=0; i<block_count; i++)
			swapped[i] = false;
	}
	//bitmap_create(1024 * 8);
}

void swap_in(size_t used_index, void *kaddr)
{
	/* not implemented */
    //bitmap_reset(swap_bitmap, used_index);
}

void swap_out(size_t swap_index, void *kaddr)
{
	/* not implemented */
    //bitmap_set(swap_bitmap, swap_index, true);
}