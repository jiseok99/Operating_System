#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include "lib/user/syscall.h"
#include "filesys/off_t.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/synch.h"

struct file
{
  struct inode* inode;
  off_t pos;
  bool deny_write;
};

struct lock lock;

void syscall_init (void);

/* user-defined */
typedef int pid_t;
void check_vaddr(void** esp, int n);
void halt (void);
void exit (int status);
pid_t exec (const char* cmd_lime);
int wait (pid_t pid);
int read (int fd, void* buffer, unsigned size);
int write (int fd, const void* buffer, unsigned size);
int fibonacci(int n);
int max_of_four_int(int a, int b, int c, int d);

bool create(const char* file, unsigned initial_size);
bool remove(const char* file);
int open(const char* file);
int filesize(int fd);
int read(int fd, void* buffer, unsigned size);
int write(int fd, const void* buffer, unsigned size);
void seek(int fd, unsigned position);
unsigned tell(int fd);
void close(int fd);

#endif /* userprog/syscall.h */
