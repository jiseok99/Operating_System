#define fraction (1 << 14)

int fp_add_fp(int a, int b);
int fp_add_int(int a, int b);
int int_sub_fp(int a, int b);
int fp_sub_fp(int a, int b);
int fp_mul_fp(int a, int b);
int fp_mul_int(int a, int b);
int int_mul_fp(int a, int b);
int fp_div_fp(int a, int b);
int fp_div_int(int a, int b);
