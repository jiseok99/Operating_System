#include "filesys/filesys.h"
#include "filesys/inode.h"
#ifndef CACHE
#define CACHE

#include "devices/block.h"

void cache_init(void);
void cache_terminate(void);
struct cache_entry* cache_select_victim(void);
struct cache_entry* cache_lookup(block_sector_t sector);
void cache_flush_entry(struct cache_entry *entry);
void cache_read(block_sector_t sector, void *buffer);
void cache_write(block_sector_t sector, const void *buffer);

#endif