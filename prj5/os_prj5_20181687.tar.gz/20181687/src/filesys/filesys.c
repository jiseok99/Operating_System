#include "threads/thread.h"
#include "filesys/filesys.h"
#include "filesys/buffer_cache.h"
#include <debug.h>
#include <stdio.h>
#include <string.h>
#include "filesys/file.h"
#include "filesys/free-map.h"
#include "filesys/inode.h"
#include "filesys/directory.h"

struct block *fs_device;

static void do_format(void);

void
filesys_init(bool format)
{
	fs_device = block_get_role(BLOCK_FILESYS);
	if (fs_device == NULL)
		PANIC("No file system device found, can't initialize file system.");

	inode_init();
	free_map_init();

	cache_init();

	if (format)
		do_format();

	free_map_open();
}

void
filesys_done(void)
{
	free_map_close();
	cache_terminate();
}

bool
filesys_create(const char *path, off_t initial_size, bool dir_or_not)
{
	block_sector_t inode_sector = 0;

	char dr[strlen(path)];
	char fn[strlen(path)];
	extract_dir_fn_from_path(path, dr, fn);
	struct dir *dir = open_from_path(dr);

	bool success = (dir != NULL && free_map_allocate(1, &inode_sector) && inode_create(inode_sector, initial_size, dir_or_not) && dir_add(dir, fn, inode_sector, dir_or_not));

	if (!success && inode_sector != 0)
		free_map_release(inode_sector, 1);

	dir_close(dir);

	return success;
}

struct file *
filesys_open(const char *name)
{
	if (strlen(name) == 0)
		return NULL;

	char dr[strlen(name) + 1];
	char fn[strlen(name) + 1];
	extract_dir_fn_from_path(name, dr, fn);
	struct dir *dir = open_from_path(dr);
	struct inode *inode = NULL;

	if (dir == NULL)
		return NULL;

	else if (strlen(fn) > 0) {
		dir_lookup(dir, fn, &inode);
		dir_close(dir);
	}

	else 
		inode = dir_get_inode(dir);
	
	if (inode == NULL)
		return NULL;
	else if(inode->removed)
		return NULL;

	return file_open(inode);
}

bool
filesys_remove(const char *name)
{
	char dr[strlen(name)];
	char fn[strlen(name)];
	extract_dir_fn_from_path(name, dr, fn);
	struct dir *dir = open_from_path(dr);

	if(dir == NULL){
		dir_close(dir);
		return false;
	}
	if(dir_remove(dir,fn) == false){
		dir_close(dir);
		return false;
	}

	dir_close(dir);
	return true;
}

/* Formats the file system. */
static void
do_format(void)
{
	printf("Formatting file system...");
	free_map_create();
	if (!dir_create(ROOT_DIR_SECTOR, 16))
		PANIC("root directory creation failed");
	free_map_close();
	printf("done.\n");
}

