#include <debug.h>
#include <string.h>
#include "filesys/buffer_cache.h"
#include "filesys/filesys.h"
#include "threads/synch.h"

struct cache_entry {
	bool valid;  
	bool dirty;     
	bool referenced;
	block_sector_t sector;
	uint8_t buffer[BLOCK_SECTOR_SIZE];

};

static size_t clock_index;
static struct cache_entry cache[128];
struct lock c_lock;

void cache_init(void)
{
	clock_index = 0;
	lock_init(&c_lock);
	for (int i = 0; i < 128; ++i)
		cache[i].valid = false;
}

void cache_flush_entry(struct cache_entry *entry)
{
	if (entry->dirty) {
		block_write(fs_device, entry->sector, entry->buffer);
		entry->dirty = false;
	}
}

void cache_terminate(void)
{
	lock_acquire(&c_lock);

	for (int i = 0; i < 128; ++i)
		if (cache[i].valid == true)
			cache_flush_entry(&(cache[i]));
	
	lock_release(&c_lock);
}


struct cache_entry* cache_lookup(block_sector_t sector)
{
	for (int i = 0; i < 128; ++i)
		if (cache[i].valid == true)
			if (cache[i].sector == sector) 
				return &(cache[i]);
		
	return NULL;
}

struct cache_entry* cache_select_victim(void)
{
	struct cache_entry *tmp = NULL;

	while (1) {
		if (cache[clock_index].valid == false)
			return &cache[clock_index];

		else if (cache[clock_index].referenced == true)
			cache[clock_index].referenced = false;

		else
			break;

		clock_index++;
		clock_index = clock_index % 128;
	}

	tmp = &cache[clock_index];
	cache_flush_entry(tmp);

	tmp->valid = false;
	return tmp;
}

void cache_read(block_sector_t sector, void *buffer)
{
	lock_acquire(&c_lock);

	struct cache_entry *tmp = cache_lookup(sector);
	if (tmp == NULL) {
		tmp = cache_select_victim();
		tmp->valid = true;
		tmp->dirty = false;
		tmp->sector = sector;
		block_read(fs_device, sector, tmp->buffer);
	}
	memcpy(buffer, tmp->buffer, BLOCK_SECTOR_SIZE);
	tmp->referenced = true;
	lock_release(&c_lock);
}

void cache_write(block_sector_t sector, const void *buffer)
{
	lock_acquire(&c_lock);

	struct cache_entry *tmp = cache_lookup(sector);
	if (tmp == NULL) {
		tmp = cache_select_victim();
		tmp->valid = true;
		tmp->dirty = false;
		tmp->sector = sector;
		block_read(fs_device, sector, tmp->buffer);
	}

	memcpy(tmp->buffer, buffer, BLOCK_SECTOR_SIZE);
	tmp->referenced = true;
	tmp->dirty = true;

	lock_release(&c_lock);
}

