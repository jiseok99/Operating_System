#include <stdint.h>
#include <debug.h>
#include <list.h>
#include <hash.h>
#include "threads/palloc.h"

struct vm_entry
{
    uint8_t type;    
    void *vaddr;     
    bool writable;     
    bool is_loaded;    

    struct file *file; 
    struct list_elem mmap_elem; 

    size_t offset;              
    size_t read_bytes;         
    size_t zero_bytes;            
    
    struct hash_elem elem; 
};

void vm_init(struct hash *vm);
static unsigned vm_hash_func(const struct hash_elem *e, void *aux);
static bool vm_less_func(const struct hash_elem *x, const struct hash_elem *y);

