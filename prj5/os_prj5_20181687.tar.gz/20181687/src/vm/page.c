#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "userprog/pagedir.h"
#include "threads/interrupt.h"
#include "threads/palloc.h"
#include "threads/thread.h"
#include "page.h"
#include "threads/vaddr.h"

void vm_init(struct hash *vm)
{
    ASSERT(vm != NULL);
    hash_init(vm, vm_hash_func, vm_less_func, 0);
}

static unsigned vm_hash_func(const struct hash_elem *e, void *aux)
{
    ASSERT(e != NULL);
    return hash_int(hash_entry(e, struct vm_entry, elem)->vaddr);
}

static bool vm_less_func(const struct hash_elem *x, const struct hash_elem *y)
{
    ASSERT(x != NULL);
    ASSERT(y != NULL);

    int X = hash_entry(x, struct vm_entry, elem)->vaddr;
    int Y = hash_entry(y, struct vm_entry, elem)->vaddr;
    return X < Y;
}
